//
//  Schema.h
//  DatalogProgram
//
//  Created by Cameron McCord on 10/25/13.
//  Copyright (c) 2013 McCord Inc. All rights reserved.
//

#ifndef __DatalogProgram__Schema__
#define __DatalogProgram__Schema__

#include <iostream>

class Schema {
public:
    
private:
    
};
#endif /* defined(__DatalogProgram__Schema__) */
