//
//  Tuple.h
//  DatalogProgram
//
//  Created by Cameron McCord on 10/25/13.
//  Copyright (c) 2013 McCord Inc. All rights reserved.
//

#ifndef __DatalogProgram__Tuple__
#define __DatalogProgram__Tuple__

using namespace std;

#include <iostream>
#include <vector>


class Tuple : public vector<string>{
public:
//    inline bool operator< (const Tuple& lhs, const Tuple& rhs);
private:
    
};
#endif /* defined(__DatalogProgram__Tuple__) */
